TP VPN brand assets — App icons
Version 1.0.0

iOS AppIcon.appiconset (with Contents.json), Android adaptive + legacy launcher icons, Web/PWA favicons and manifest icons, universal PNGs.

License
  TP VPN brand assets — © TP VPN, all rights reserved; fonts under OFL; flags MIT
  See LICENSE-BRAND.md for the brand terms; fonts: LICENSE-Inter.txt (SIL OFL 1.1);
  flags: circle-flags by HatScripts (MIT).

Regenerate
  packages/brand/scripts/build-assets.mjs in the tp-design-system repository.

Contents (39 files)
  LICENSE-BRAND.md  (2.1 KB)
  app-icon/android/ic_launcher-144.png  (2.7 KB)
  app-icon/android/ic_launcher-192.png  (3.6 KB)
  app-icon/android/ic_launcher-48.png  (940 B)
  app-icon/android/ic_launcher-512.png  (11.1 KB)
  app-icon/android/ic_launcher-72.png  (1.4 KB)
  app-icon/android/ic_launcher-96.png  (1.8 KB)
  app-icon/android/ic_launcher_background.png  (1.2 KB)
  app-icon/android/ic_launcher_foreground.png  (3.5 KB)
  app-icon/android/ic_launcher_foreground.svg  (2.4 KB)
  app-icon/ios/AppIcon-1024.png  (16.0 KB)
  app-icon/ios/AppIcon-120.png  (2.2 KB)
  app-icon/ios/AppIcon-152.png  (2.8 KB)
  app-icon/ios/AppIcon-167.png  (3.1 KB)
  app-icon/ios/AppIcon-180.png  (3.3 KB)
  app-icon/ios/AppIcon-20.png  (440 B)
  app-icon/ios/AppIcon-29.png  (601 B)
  app-icon/ios/AppIcon-40.png  (806 B)
  app-icon/ios/AppIcon-58.png  (1.1 KB)
  app-icon/ios/AppIcon-60.png  (1.1 KB)
  app-icon/ios/AppIcon-76.png  (1.4 KB)
  app-icon/ios/AppIcon-80.png  (1.5 KB)
  app-icon/ios/AppIcon-87.png  (1.6 KB)
  app-icon/ios/Contents.json  (2.1 KB)
  app-icon/universal/tp-vpn-icon-1024.png  (25.7 KB)
  app-icon/universal/tp-vpn-icon-128.png  (2.3 KB)
  app-icon/universal/tp-vpn-icon-256.png  (4.9 KB)
  app-icon/universal/tp-vpn-icon-32.png  (670 B)
  app-icon/universal/tp-vpn-icon-512.png  (11.1 KB)
  app-icon/universal/tp-vpn-icon-64.png  (1.2 KB)
  app-icon/web/README.md  (1.5 KB)
  app-icon/web/apple-touch-icon.png  (3.3 KB)
  app-icon/web/favicon-16.png  (378 B)
  app-icon/web/favicon-32.png  (670 B)
  app-icon/web/favicon.ico  (2.0 KB)
  app-icon/web/icon-192.png  (3.6 KB)
  app-icon/web/icon-512.png  (11.1 KB)
  app-icon/web/icon-maskable-512.png  (5.8 KB)
  app-icon/web/icon.svg  (2.4 KB)
