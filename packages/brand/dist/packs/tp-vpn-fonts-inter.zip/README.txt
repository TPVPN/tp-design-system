TP VPN brand assets — Inter fonts
Version 1.0.0

Inter Regular / Medium / SemiBold / Bold / ExtraBold (TTF) under the SIL Open Font License 1.1.

License
  TP VPN brand assets — © TP VPN, all rights reserved; fonts under OFL; flags MIT
  See LICENSE-BRAND.md for the brand terms; fonts: LICENSE-Inter.txt (SIL OFL 1.1);
  flags: circle-flags by HatScripts (MIT).

Regenerate
  packages/brand/scripts/build-assets.mjs in the tp-design-system repository.

Contents (7 files)
  LICENSE-BRAND.md  (2.1 KB)
  fonts/Inter-Bold.ttf  (318.8 KB)
  fonts/Inter-ExtraBold.ttf  (319.7 KB)
  fonts/Inter-Medium.ttf  (317.7 KB)
  fonts/Inter-Regular.ttf  (317.2 KB)
  fonts/Inter-SemiBold.ttf  (318.4 KB)
  fonts/LICENSE-Inter.txt  (4.3 KB)
