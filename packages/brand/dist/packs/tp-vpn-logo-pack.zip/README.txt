TP VPN brand assets — Logo pack
Version 1.0.0

All logo variants as SVG (outlined wordmark) and PNG @1x/@2x, plus the clear-space and construction-grid diagrams.

License
  TP VPN brand assets — © TP VPN, all rights reserved; fonts under OFL; flags MIT
  See LICENSE-BRAND.md for the brand terms; fonts: LICENSE-Inter.txt (SIL OFL 1.1);
  flags: circle-flags by HatScripts (MIT).

Regenerate
  packages/brand/scripts/build-assets.mjs in the tp-design-system repository.

Contents (30 files)
  LICENSE-BRAND.md  (2.1 KB)
  logo/png/tp-vpn-logo-horizontal-reversed@1x.png  (14.2 KB)
  logo/png/tp-vpn-logo-horizontal-reversed@2x.png  (33.3 KB)
  logo/png/tp-vpn-logo-horizontal@1x.png  (16.8 KB)
  logo/png/tp-vpn-logo-horizontal@2x.png  (38.8 KB)
  logo/png/tp-vpn-logo-mark-mono-black@1x.png  (12.2 KB)
  logo/png/tp-vpn-logo-mark-mono-black@2x.png  (28.5 KB)
  logo/png/tp-vpn-logo-mark-mono-white@1x.png  (11.1 KB)
  logo/png/tp-vpn-logo-mark-mono-white@2x.png  (25.7 KB)
  logo/png/tp-vpn-logo-mark-reversed@1x.png  (10.1 KB)
  logo/png/tp-vpn-logo-mark-reversed@2x.png  (23.3 KB)
  logo/png/tp-vpn-logo-mark@1x.png  (11.1 KB)
  logo/png/tp-vpn-logo-mark@2x.png  (25.7 KB)
  logo/png/tp-vpn-logo-stacked@1x.png  (28.2 KB)
  logo/png/tp-vpn-logo-stacked@2x.png  (69.4 KB)
  logo/png/tp-vpn-wordmark-white@1x.png  (11.3 KB)
  logo/png/tp-vpn-wordmark-white@2x.png  (27.0 KB)
  logo/png/tp-vpn-wordmark@1x.png  (13.5 KB)
  logo/png/tp-vpn-wordmark@2x.png  (33.6 KB)
  logo/svg/tp-vpn-logo-clearspace.svg  (40.3 KB)
  logo/svg/tp-vpn-logo-grid.svg  (31.0 KB)
  logo/svg/tp-vpn-logo-horizontal-reversed.svg  (4.6 KB)
  logo/svg/tp-vpn-logo-horizontal.svg  (4.6 KB)
  logo/svg/tp-vpn-logo-mark-mono-black.svg  (2.4 KB)
  logo/svg/tp-vpn-logo-mark-mono-white.svg  (2.4 KB)
  logo/svg/tp-vpn-logo-mark-reversed.svg  (2.4 KB)
  logo/svg/tp-vpn-logo-mark.svg  (2.4 KB)
  logo/svg/tp-vpn-logo-stacked.svg  (4.6 KB)
  logo/svg/tp-vpn-wordmark-white.svg  (2.0 KB)
  logo/svg/tp-vpn-wordmark.svg  (2.0 KB)
