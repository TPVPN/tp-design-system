TP VPN brand assets — Social kit
Version 1.0.0

Open Graph default image, GitHub social preview, square avatar and X/Twitter header.

License
  TP VPN brand assets — © TP VPN, all rights reserved; fonts under OFL; flags MIT
  See LICENSE-BRAND.md for the brand terms; fonts: LICENSE-Inter.txt (SIL OFL 1.1);
  flags: circle-flags by HatScripts (MIT).

Regenerate
  packages/brand/scripts/build-assets.mjs in the tp-design-system repository.

Contents (5 files)
  LICENSE-BRAND.md  (2.1 KB)
  social/avatar-1024.png  (17.5 KB)
  social/github-social-preview-1280x640.png  (19.1 KB)
  social/og-default.png  (17.7 KB)
  social/twitter-header-1500x500.png  (24.9 KB)
